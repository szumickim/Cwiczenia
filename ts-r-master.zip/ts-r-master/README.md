# Projekt ts-r

Jest repozytorium zadań dla studentów kierunku matematyka (stosowana) wydziału FTIMS PŁ. Zawiera zadania i rozwiązania (studenckie) ćwiczeń do przedmiotu Szeregi czasowe i prognozowanie w biznesie.

# Zadania

Pierwszy blok ćwiczeń będzie dotyczył podstaw programowania w R. Instrukcje pętli, deklarowanie zmiennych, pisanie funkcji
