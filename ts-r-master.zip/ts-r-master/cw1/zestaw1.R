## Zadanie 

## Przygotowac funkcje, która w zależności od podanego parametru wypisuje litery 
## alfabetu w pętli (po 'z' znowu 'a') i przerywa po wypisaniu n liter

alfabet = function(n){
  
}