## Zadanie

## Napisać funkcje, ktora znajduje najczesciej powtarzajaca litere się w tekscie

moda_z_tekstu = function(zdanie){
  
}