## Zadanie

## Przygotować funkcję, która dla danej liczby znajduje sumę jej cyfr

suma_cyfr = function(liczba){
  
}