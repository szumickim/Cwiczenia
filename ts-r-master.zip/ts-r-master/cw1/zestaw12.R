## Zadanie 

## Przygotowac funkcje, ktora sprawdza czy w danym slowie znajduje sie litera a potem zwraca 
## wektor pozycji na ktorych zostaly odszukane te litery. Niech domyslnie ignoruje wielkosc liter

znajdz_litere = function(slowo, litera){
  
}

## przyklad
## znajdz_litere('Matematyka', 'a') -> c(2,6,10) 