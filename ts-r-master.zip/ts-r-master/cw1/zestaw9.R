## Zadanie

## Napisać program ktory dla zamienia znaki małej litery na wielkiej i odwrotnie w słowie 
## przekazanym przez parametr

zamiana_liter = function(slowo){
  
}