## Zadanie

## Napisać funkcje szyfrujaca i deszyfrujaca za pomoca szyfru Cezara o okreslonym kroku
## Szyfr Cezara polega na przesuniecia kazdego znaku w slowie o stala liczbe znakow

szyfrowanie = function(slowo, przesuniecie){

  }

deszyfrowanie = function(zaszyfrowane, przesuniecie){

  }
p = 5
zdanie = 'Ala ma kota'
kod = szyfrowanie(zdanie, przesuniecie = p)
print(kod)
odkodowane = deszyfrowanie(kod, przesuniecie = p)
print(odkodowane)
