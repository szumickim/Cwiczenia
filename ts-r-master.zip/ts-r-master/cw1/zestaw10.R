## Zadanie

## Napisać funkcję, która sprawdzi czy w podanym wyrażeniu algebraicznym są poprawnie zadane nawiasy
## Np 3*(2+4*4)-2+(3+4^2)

sprawdzacz_nawiasow = function(){
  
}