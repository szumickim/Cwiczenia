## Zadanie 

## Przygotowac funkcje, ktora podaje liczbe spółgłosek w zadanym słowie

ilosc_spolglosek = function(){
  
}