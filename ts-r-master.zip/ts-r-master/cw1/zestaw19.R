## Zadanie

## Napisac funkcje ktora zamienia slowo opisujace liczbe w systemi binarnym na liczbe w systemie 
## dziesietnym

liczba = '1100' # to jest 12

na_dziesietny = function(liczba_binarna){
  
}

na_dziesietny(liczba)