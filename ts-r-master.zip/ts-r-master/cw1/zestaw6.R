## Zadanie 

## Przygotować funkcję która dla danej liczby znajduje największą liczbę całkowitę mniejszą 
## od pierwiastka z danej

mniejsza_od_pierwiastka = function(liczba){
  
}