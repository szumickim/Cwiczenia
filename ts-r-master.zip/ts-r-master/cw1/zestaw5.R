## Zadanie

## Napisać funkcję, która znajduje liczbę odwrotną w mnożeniu w ciele $Z_p$
## Funkcja niech działa przy założeniu że p jest liczbą pierwszą - bowiem tylko wtedy jesteśmy
## pewni istnienia elementu odwrotnego w mnożeniu

odwrotny = function(argument, p){
  
}