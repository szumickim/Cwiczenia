## Zadanie 

## Napisać funkcję, ktora dla danego wektora liczb wylicza sume drugiej najmniejszej liczby i 
## drugiej największej. Działa przy założeniu, że wektor ma conajmniej 3 elementy

suma_vice_ekstremum = function(){
  
}