## Zadanie

## Przygotowac funkcje, ktora w zaleznosci od podanego rysuje na ekranie odpowiednia duza choinke
## np dla n=5 powinno narysować
##    *
##   * *
##  * * *
## * * * *
##* * * * *
##    *

choinka = function(n){
  
}