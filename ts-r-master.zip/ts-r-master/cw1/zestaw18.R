## Zadanie

## Napisz program generujacy macierz z tabliczka mnozenia o okreslonym rozmiarze

tabliczka_mnozenia = function(rozmiar){
  
}

## np. tabliczka_mnozenia(4)
## 1 2 3 4
## 2 4 6 8
## 3 6 9 12
## 4 8 12 16