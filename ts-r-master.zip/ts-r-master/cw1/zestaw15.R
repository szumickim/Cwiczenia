## Zadanie 

## Przygotowac funkcje ktora rysuje podroz pewnego 'X' tj przesuwa w prawo X w kolejnych linijkach 
## pelny -

podrozujacy_x = function(dlugosc_linii){
  
}

## np
## podrozujacy_x(5)

## X----
## -X---
## --X--
## ---X-
## ----X