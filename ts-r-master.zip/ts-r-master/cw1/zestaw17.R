## Zadanie 

## Napisz funkcje wyznaczajaca liczbe cyfr podanych w tekscie

ilosc_cyfr = function(zdanie){
  
}