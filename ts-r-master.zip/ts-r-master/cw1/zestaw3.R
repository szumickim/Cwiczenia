## Zadanie 

## Przygotować funkcję, ktora oblicza sume wszystkich dzielnikow pierwszych danej liczby

suma_dzielikow_pierwszych = function(liczba){
  
}