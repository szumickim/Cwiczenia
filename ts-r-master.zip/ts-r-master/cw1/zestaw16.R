## Zadanie 

## Napisac funkcje, ktora dla podanego dnia, miesiaca i roku podaje jaki jest dzien nastepny

dzien_nastepny = function(data){
  
}

przykladowa_data = c(28,2,2019) #28 luty 2019
poprawna_odpowiedz = c(1,3,2019) #nastepny dzien to 1 marca 2019
