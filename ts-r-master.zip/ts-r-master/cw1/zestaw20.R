## Zadanie

## Napisać funkcję znajduja miejsce zerowe pewnej funkcji stosujac algorytm bisekcji

bisekcja = function(f, lewa_krawedz_przedzialu, prawa_krawedz_przedzialu, dokladnosc){
  
}

bisekcja(sin, 3, 4)

sin(3)
sin(4)
